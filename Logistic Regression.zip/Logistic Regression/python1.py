#!/usr/bin/env python
# coding: utf-8

# import pandas as pd 
# import numpy as np
# import streamlit as st
# import pickle
# from PIL import Image 
# 
# pickle_in = open(r"C:\Users\MAYUR\Desktop\Logistic Regression\Reg_model.pkl", 'rb') 
# classifier = pickle.load(pickle_in)
# 
# def welcome(): 
#     return 'welcome all'
# 
# def prediction(Sex, Age, SibSp, Parch):   
#    
#     prediction = classifier.predict([[Sex, Age, SibSp, Parch]]) 
#     print(prediction) 
#     return prediction 
# 
# def Main():
#     st.title('Titanic predictions')
#     
#     Sex = st.text_input("Sex",': M=1,F=0') 
#     Age = st.text_input("Age") 
#     SibSp = st.text_input("SibSp") 
#     Parch = st.text_input("Parch") 
#     result ="" 
#     
#     
#     
#     if st.button("Predict"): 
#         result = prediction(Sex, Age, SibSp, Parch) 
#     st.success('The output is {}'.format(result)) 
# 
# if __name__=='__Main__': 
#     Main()

# In[ ]:


import pandas as pd
import numpy as np
import streamlit as st
import pickle
from PIL import Image

pickle_in = open(r"C:\Users\MAYUR\Desktop\Logistic Regression\Reg_model.pkl", 'rb')
classifier = pickle.load(pickle_in)

def welcome():
    return 'welcome all'

def prediction(Sex, Age, SibSp, Parch):
    # Convert input variables to integers
    Sex = int(Sex)
    Age = int(Age)
    SibSp = int(SibSp)
    Parch = int(Parch)
    
    prediction = classifier.predict([[Sex, Age, SibSp, Parch]])
    return prediction

def Main():
    st.title('Titanic predictions')
    
    Sex = st.text_input("Sex", ': M=1,F=0')
    Age = st.text_input("Age")
    SibSp = st.text_input("SibSp")
    Parch = st.text_input("Parch")
    result = ""
    
    if st.button("Predict"):
        result = prediction(Sex, Age, SibSp, Parch)
    st.success('The output is {}'.format(result))

if __name__ == '__main__':
    Main()

