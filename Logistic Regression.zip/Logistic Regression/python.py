import pandas as pd
import numpy as np
import streamlit as st
import pickle
from PIL import Image
from sklearn.preprocessing import MinMaxScaler

pickle_in = open(r"C:\Users\MAYUR\Desktop\Logistic Regression\Reg_model.pkl", 'rb')
classifier = pickle.load(pickle_in)

pickle_sc = open(r"C:\Users\MAYUR\Desktop\Logistic Regression\Scale.pkl", 'rb')
Scaler = pickle.load(pickle_sc)


def welcome():
    return 'welcome all'

def prediction(Sex, Age, SibSp, Parch):
    # Convert input variables to integers
    Sex = int(Sex)
    Age = float(Age)
    SibSp = int(SibSp)
    Parch = int(Parch)
    Age = Scaler.fit_transform(np.array([[Age]]))[0][0]
    
    prediction = classifier.predict([[Sex, Age, SibSp, Parch]])
    return prediction

def Main():
    st.title('Titanic predictions')
    
    Sex = st.text_input("Sex", ': M=1,F=0')
    Age = st.text_input("Age")
    SibSp = st.text_input("SibSp")
    Parch = st.text_input("Parch")
    result = ""
    
    if st.button("Predict"):
        result = prediction(Sex, Age, SibSp, Parch)
    st.success('The output is {}'.format(result))

if __name__ == '__main__':
    Main()